// export const API_URL="http://localhost:3000/apiUrl"
// export const API_URL="https://dev-ai-signlab.netlify.app/apiUrl"
export const API_URL="https://ai-sign-language.vercel.app/apiUrl"
// export const API_URL="http://ai-sign-env.eba-z9pwwi3e.us-east-1.elasticbeanstalk.com"